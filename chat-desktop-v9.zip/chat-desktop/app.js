'use strict';
// chat desktop — Matrix client for Julio's own server (WhatsApp via mautrix-whatsapp). Same rules as the A06 app.
const DEFAULT_HS = 'https://continuwuity-production-04127fa5.up.railway.app';
const BRIDGE = 'https://mautrix-whatsapp-production.up.railway.app';
const HIDDEN = 'sig.hidden';
const DRAFT = 'sig.draft';   // {text, ts}: a draft written by Claude (chat MCP)
const TRANSCRIBER = 'https://transcriber-production-893ce450.up.railway.app';
const QUICK = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
const EMOJI = '😀 😁 😂 🤣 😊 😍 😘 😎 🤔 😅 😭 😢 😡 😱 😴 🙄 👍 👎 👏 🙌 🙏 💪 👀 🤝 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 🔥 ✨ 🎉 💯 ✅ ❌ ⚡ 🌟 😮 🥲 🥹 😬 🤯 🤡 💀 👌'.split(' ');
const HOST = window.host || { auth: async () => {}, open: async u => window.open(u), title: async t => { document.title = t; }, remux: null };
const $ = s => document.querySelector(s);
const LS = localStorage;
const TEST = LS.getItem('testmode') === '1';   // no read receipts, typing or sending (used for automated checks)

// ---------------- prefs / theme ----------------
const prefs = {
  get(k, d) { const v = LS.getItem('p_' + k); return v === null ? d : JSON.parse(v); },
  set(k, v) { LS.setItem('p_' + k, JSON.stringify(v)); }
};
function applyTheme() {
  document.body.classList.toggle('blue', prefs.get('accent', 'gray') === 'blue');
  document.body.classList.toggle('soft', !prefs.get('amoled', true));
  const sz = { small: '14px', normal: '15px', large: '16.5px' }[prefs.get('textsize', 'normal')] || '15px';
  document.documentElement.style.setProperty('--fs', sz);
}

// ---------------- state ----------------
const S = {
  hs: LS.getItem('hs') || DEFAULT_HS, token: LS.getItem('token'), me: LS.getItem('me'),
  since: null, firstSync: false, rooms: new Map(), direct: new Set(),
  filter: 0, query: '', cur: null
};
function newRoom(id) {
  return { id, name: null, avatar: null, alias: null, preview: '', pid: null, dm: false, mu: false, pinned: false, ts: 0, unread: 0,
    joined: 0, hidden: -1, heroes: [], names: {}, typing: [], read: {} };
}
const R = {
  get(id) { let r = S.rooms.get(id); if (!r) { r = newRoom(id); S.rooms.set(id, r); } return r; },
  isBot: u => u.startsWith('@whatsappbot:'),
  name(r) {
    if (r.name) return r.name;
    const n = r.heroes.filter(h => h !== S.me && !R.isBot(h)).map(h => R.nameOf(r, h));
    return n.length ? n.join(', ') : 'Chat';
  },
  nameOf(r, u) { const n = r.names[u]; if (n) return n; const c = u.indexOf(':'); return c > 1 ? u.slice(1, c) : u; },
  hidden: r => r.hidden >= 0 && !r.mu && r.ts <= r.hidden,
  unread: r => r.unread > 0 || r.mu,
  isDm: r => S.direct.has(r.id) || (!r.name && r.joined > 0 && r.joined <= 2),
  system(r) {
    if (r.alias && r.alias.startsWith('#admins:')) return true;
    if (r.name && r.name.endsWith('Admin Room')) return true;
    return !r.name && r.joined <= 2 && r.heroes.some(R.isBot);
  },
  readAt(r, ts) {
    let n = 0; for (const u in r.read) if (r.read[u] >= ts) n++;
    if (!n) return false; return r.dm ? true : n >= Math.max(1, r.joined - 2);
  },
  typingText(r) {
    if (!r.typing.length) return null;
    return r.dm ? 'typing…' : R.nameOf(r, r.typing[0]) + (r.typing.length > 1 ? ' and others are' : ' is') + ' typing…';
  }
};

// ---------------- http ----------------
const enc = encodeURIComponent;
async function api(method, path, body, opts = {}) {
  const url = path.startsWith('http') ? path : S.hs + path;
  const h = {};
  if (S.token) h.Authorization = 'Bearer ' + S.token;
  let b;
  if (body instanceof Blob || body instanceof ArrayBuffer || body instanceof Uint8Array) { b = body; h['Content-Type'] = opts.ctype || 'application/octet-stream'; }
  else if (body !== undefined && body !== null) { b = JSON.stringify(body); h['Content-Type'] = 'application/json'; }
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), opts.timeout || 60000);
  try {
    const r = await fetch(url, { method, headers: h, body: b, signal: ctl.signal });
    let j = {};
    try { j = await r.json(); } catch (e) {}
    if (r.status === 401 && j.errcode === 'M_UNKNOWN_TOKEN') logout();
    return { code: r.status, json: j };
  } finally { clearTimeout(t); }
}
const roomPath = id => '/_matrix/client/v3/rooms/' + enc(id);
const userRoomPath = id => '/_matrix/client/v3/user/' + enc(S.me) + '/rooms/' + enc(id);
const prov = (m, p, b) => api(m, BRIDGE + '/_matrix/provision/v3' + p + (p.includes('?') ? '&' : '?') + 'user_id=' + enc(S.me), b);
const media = (mxc, px) => {
  if (!mxc || !mxc.startsWith('mxc://')) return '';
  const sm = mxc.slice(6);
  return px ? `${S.hs}/_matrix/client/v1/media/thumbnail/${sm}?width=${px}&height=${px}&method=scale` : `${S.hs}/_matrix/client/v1/media/download/${sm}`;
};
async function sendContent(roomId, type, content, txn) {
  if (TEST) throw new Error('test mode: not sending');
  const r = await api('PUT', roomPath(roomId) + '/send/' + type + '/' + enc(txn || ('d' + Date.now() + Math.random().toString(36).slice(2))), content);
  if (r.code !== 200) throw new Error(r.json.error || 'HTTP ' + r.code);
  return r.json.event_id;
}

// ---------------- auth ----------------
async function login(hs, user, pass) {
  S.hs = hs.replace(/\/+$/, ''); S.token = null;
  const r = await api('POST', '/_matrix/client/v3/login', { type: 'm.login.password', identifier: { type: 'm.id.user', user }, password: pass, initial_device_display_name: 'chat (mint)' });
  if (r.code !== 200) return r.json.error || 'HTTP ' + r.code;
  S.token = r.json.access_token; S.me = r.json.user_id;
  LS.setItem('hs', S.hs); LS.setItem('token', S.token); LS.setItem('me', S.me);
  return null;
}
function logout() {
  S.token = null; LS.removeItem('token'); LS.removeItem('cache'); S.rooms.clear(); S.since = null; S.firstSync = false;
  HOST.auth('', '');
  showLogin();
}

// ---------------- cache ----------------
function loadCache() {
  try {
    const c = JSON.parse(LS.getItem('cache') || 'null');
    if (!c) return;
    S.since = c.since; (c.direct || []).forEach(d => S.direct.add(d));
    for (const o of c.rooms || []) S.rooms.set(o.id, Object.assign(newRoom(o.id), o, { typing: [] }));
    S.firstSync = !!S.since;
  } catch (e) { S.rooms.clear(); S.since = null; }
}
let lastSave = 0;
function saveCache(force) {
  if (!force && Date.now() - lastSave < 15000) return;
  lastSave = Date.now();
  const rooms = [...S.rooms.values()].map(r => {
    const o = Object.assign({}, r); delete o.typing;
    const n = {}; r.heroes.forEach(h => { if (r.names[h]) n[h] = r.names[h]; }); o.names = n;
    return o;
  });
  try { LS.setItem('cache', JSON.stringify({ since: S.since, direct: [...S.direct], rooms })); } catch (e) {}
}

// ---------------- sync ----------------
const FILTER = JSON.stringify({ room: { timeline: { limit: 12 }, state: { lazy_load_members: true } }, presence: { not_types: ['*'] } });
let syncing = false;
async function syncLoop() {
  if (syncing) return; syncing = true;
  while (S.token) {
    try {
      const p = '/_matrix/client/v3/sync?filter=' + enc(FILTER) + '&timeout=' + (S.firstSync ? 30000 : 0) + (S.since ? '&since=' + enc(S.since) : '');
      const r = await api('GET', p, null, { timeout: 45000 });
      if (r.code !== 200) { await sleep(5000); continue; }
      const wasFirst = !S.firstSync;
      S.firstSync = true;
      handleSync(r.json);
      S.since = r.json.next_batch || S.since;
      if (wasFirst) renderList();
      saveCache(false);
    } catch (e) { await sleep(5000); }
  }
  syncing = false;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function handleSync(s) {
  for (const e of (s.account_data && s.account_data.events) || []) {
    if (e.type === 'm.direct') {
      S.direct.clear();
      for (const k in e.content || {}) (e.content[k] || []).forEach(id => S.direct.add(id));
      for (const r of S.rooms.values()) r.dm = R.isDm(r);
    }
  }
  const rj = s.rooms || {};
  for (const id in rj.invite || {}) api('POST', roomPath(id) + '/join', {});
  for (const id in rj.leave || {}) S.rooms.delete(id);
  const live = {};
  for (const id in rj.join || {}) {
    const jr = rj.join[id], r = R.get(id);
    const sum = jr.summary || {};
    if (sum['m.heroes']) r.heroes = sum['m.heroes'];
    if (sum['m.joined_member_count'] !== undefined) r.joined = sum['m.joined_member_count'];
    applyState(r, (jr.state && jr.state.events) || []);
    r.dm = R.isDm(r);   // decide DM-ness before building previews (DMs get no name prefix)
    const tl = (jr.timeline && jr.timeline.events) || [];
    for (const e of tl) { if (e.state_key !== undefined) applyState(r, [e]); notePreview(r, e); }
    if (jr.unread_notifications) r.unread = jr.unread_notifications.notification_count || 0;
    for (const e of (jr.ephemeral && jr.ephemeral.events) || []) {
      if (e.type === 'm.typing') r.typing = (e.content.user_ids || []).filter(u => u !== S.me);
      else if (e.type === 'm.receipt') {
        for (const ev in e.content) for (const rt of ['m.read', 'm.read.private']) {
          const users = e.content[ev][rt] || {};
          for (const u in users) { if (u === S.me || R.isBot(u)) continue; const ts = users[u].ts || 0; if (!r.read[u] || ts > r.read[u]) r.read[u] = ts; }
        }
      }
    }
    for (const e of (jr.account_data && jr.account_data.events) || []) {
      const c = e.content || {};
      if (e.type === HIDDEN) r.hidden = c.ts === undefined ? -1 : c.ts;
      else if (e.type === DRAFT) applyDraft(r, c);
      else if (e.type === 'm.marked_unread' || e.type === 'com.famedly.marked_unread') r.mu = !!c.unread;
      else if (e.type === 'm.tag') r.pinned = !!(c.tags && c.tags['m.favourite']);
    }
    r.dm = R.isDm(r);
    live[id] = tl;
  }
  renderList();
  if (S.cur && live[S.cur.id]) Chat.onEvents(live[S.cur.id]);
}

// a draft from Claude: each device applies it once (draftts_), appended to whatever is already typed
function applyDraft(r, c) {
  const text = c.text || '', ts = c.ts || 0;
  if (!text.trim() || ts <= +(LS.getItem('draftts_' + r.id) || 0)) return;
  LS.setItem('draftts_' + r.id, ts);
  const join = v => v.trim() ? v + '\n\n' + text : text;
  if (Chat.room && Chat.room.id === r.id && !Chat.editing) { $('#inp').value = join($('#inp').value); autosize(); updateSend(); toast('Draft from Claude'); }
  else LS.setItem('draft_' + r.id, join(LS.getItem('draft_' + r.id) || ''));
}
function clearRemoteDraft(roomId) {
  if (LS.getItem('draftts_' + roomId) === null) return;
  LS.removeItem('draftts_' + roomId);
  bg(() => api('PUT', userRoomPath(roomId) + '/account_data/' + DRAFT, {}));
}

function applyState(r, evs) {
  for (const e of evs) {
    const c = e.content || {};
    if (e.type === 'm.room.name') r.name = c.name || null;
    else if (e.type === 'm.room.avatar') r.avatar = c.url || null;
    else if (e.type === 'm.room.canonical_alias') r.alias = c.alias || null;
    else if (e.type === 'm.room.member' && c.displayname) r.names[e.state_key] = c.displayname;
  }
}

// stickers never count; bridge sticker notices count as stickers; edits never bump the time
function isStickerNotice(c) {
  if (!c || c.msgtype !== 'm.notice') return false;
  const b = (c.body || '').toLowerCase().replace(/^\* /, '');
  return b.startsWith('old sticker') || b.startsWith('failed to bridge sticker');
}
const isSticker = c => !!((c.info && c.info['fi.mau.sticker']) || isStickerNotice(c['m.new_content']) || isStickerNotice(c));
function previewText(c) {
  const b = c.body || '';
  switch (c.msgtype) {
    case 'm.image': return 'Photo';
    case 'm.video': return 'Video';
    case 'm.audio': return c['org.matrix.msc3245.voice'] ? 'Voice message' : 'Audio';
    case 'm.file': return 'File: ' + b;
    case 'm.location': return 'Location';
    case 'm.notice': {
      const m = /^\*?\s*failed to bridge (\w+)/i.exec(b);
      if (m) { const w = m[1].toLowerCase(); return w === 'voice' ? 'Voice message' : w[0].toUpperCase() + w.slice(1); }
    }
  }
  return b.replace(/\n/g, ' ');
}
function prefix(r, e) { return e.sender === S.me ? 'You: ' : r.dm ? '' : R.nameOf(r, e.sender) + ': '; }
function notePreview(r, e) {
  const c = e.content || {}, ts = e.origin_server_ts || 0;
  if (e.type === 'm.sticker') return;
  if (e.type === 'm.room.message') {
    if (isSticker(c)) return;
    const rel = c['m.relates_to'];
    if (rel && rel.rel_type === 'm.replace') { if (rel.event_id === r.pid && c['m.new_content']) r.preview = prefix(r, e) + previewText(c['m.new_content']); return; }
    r.preview = prefix(r, e) + previewText(c); r.pid = e.event_id; r.ts = Math.max(r.ts, ts);
  } else if (e.type === 'm.reaction' || e.type === 'm.room.redaction') {
    r.ts = Math.max(r.ts, ts);
    if (e.type === 'm.room.redaction' && (e.redacts || c.redacts) === r.pid) r.preview = prefix(r, e) + 'Deleted message';
  } else if (!r.ts) r.ts = ts;
}

// ---------------- room actions ----------------
const bg = f => f().catch(() => {});
function hideRoom(r, hide) {
  const ts = hide ? r.ts : -1; r.hidden = ts; if (hide) r.mu = false;
  bg(async () => { await api('PUT', userRoomPath(r.id) + '/account_data/' + HIDDEN, { ts }); if (hide) await api('PUT', userRoomPath(r.id) + '/account_data/m.marked_unread', { unread: false }); });
  if (hide) toast('Hidden until there’s something new');
}
function pinRoom(r, pin) {
  r.pinned = pin;
  bg(() => pin ? api('PUT', userRoomPath(r.id) + '/tags/m.favourite', { order: 0.5 }) : api('DELETE', userRoomPath(r.id) + '/tags/m.favourite'));
}
function markUnread(r, un) {
  r.mu = un; if (!un) r.unread = 0;
  bg(() => api('PUT', userRoomPath(r.id) + '/account_data/m.marked_unread', { unread: un }));
}
function markRead(roomId, eventId) {
  if (!eventId || eventId.startsWith('~') || TEST) return;
  const r = S.rooms.get(roomId); const was = r && r.mu;
  if (r) { r.unread = 0; r.mu = false; }
  const pub = prefs.get('sendread', true);
  bg(async () => {
    await api('POST', roomPath(roomId) + '/read_markers', { 'm.fully_read': eventId, [pub ? 'm.read' : 'm.read.private']: eventId });
    if (was) await api('PUT', userRoomPath(roomId) + '/account_data/m.marked_unread', { unread: false });
  });
}
async function markRoomRead(r) {
  markUnread(r, false);
  const res = await api('GET', roomPath(r.id) + '/messages?dir=b&limit=1');
  const ch = res.json.chunk || [];
  if (ch.length) markRead(r.id, ch[0].event_id);
}
let lastTyping = 0;
function typing(on) {
  if (!S.cur || TEST) return;
  if (on && !prefs.get('sendtyping', true)) return;
  const now = Date.now();
  if (on && now - lastTyping < 4000) return;
  if (!on && !lastTyping) return;
  lastTyping = on ? now : 0;
  bg(() => api('PUT', roomPath(S.cur.id) + '/typing/' + enc(S.me), on ? { typing: true, timeout: 6000 } : { typing: false }));
}

// ---------------- small helpers ----------------
function h(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; }
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pad = n => String(n).padStart(2, '0');
const clock = ts => { const d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
const timer = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return pad(Math.floor(s / 60)) + ':' + pad(s % 60); };
function sameDay(a, b) { const x = new Date(a), y = new Date(b); return x.toDateString() === y.toDateString(); }
function listTime(ts) {
  if (!ts) return '';
  const now = Date.now();
  if (sameDay(ts, now)) return clock(ts);
  if (sameDay(ts, now - 86400000)) return 'Yesterday';
  if (now - ts < 6 * 86400000) return new Date(ts).toLocaleDateString('en-US', { weekday: 'short' });
  const d = new Date(ts); return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + String(d.getFullYear()).slice(2);
}
function dayLabel(ts) {
  if (sameDay(ts, Date.now())) return 'Today';
  if (sameDay(ts, Date.now() - 86400000)) return 'Yesterday';
  const d = new Date(ts), y = d.getFullYear() === new Date().getFullYear();
  return d.toLocaleDateString('en-US', y ? { weekday: 'long', day: 'numeric', month: 'long' } : { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}
function initials(n) {
  const out = []; for (const w of n.trim().split(/\s+/)) { const ch = [...w][0]; if (ch && /[\p{L}\p{N}]/u.test(ch)) out.push(ch.toUpperCase()); if (out.length === 2) break; }
  return out.join('') || [...n][0] || '?';
}
function shade(n) { let x = 0; for (const c of n) x = (x * 31 + c.charCodeAt(0)) | 0; const v = 0x30 + (Math.abs(x) % 0x1c); return `rgb(${v},${v},${v})`; }
function avatarEl(name, mxc, size, isDm) {
  const a = h('div', 'av');
  a.style.width = a.style.height = size + 'px'; a.style.fontSize = Math.round(size * 0.36) + 'px';
  a.style.background = shade(name);
  a.textContent = initials(name);
  if (!isDm && mxc) {   // people never get a picture; groups keep theirs
    const img = new Image();
    img.onload = () => { a.textContent = ''; a.style.backgroundImage = `url("${img.src}")`; };
    img.src = media(mxc, 96);
    if (prefs.get('accent', 'gray') !== 'blue') a.classList.add('gray');
  }
  return a;
}
function emojiOnly(s) {
  if (!s) return false; const t = s.trim(); if (!t || t.length > 24) return false;
  const rx = /^(?:\p{Extended_Pictographic}(?:️|‍\p{Extended_Pictographic}|[\u{1F3FB}-\u{1F3FF}])*\s*){1,3}$/u;
  return rx.test(t);
}
function linkify(text) {
  return esc(text).replace(/\b((?:https?:\/\/|www\.)[^\s<]+[^\s<.,;:!?)\]'"])/gi, u => `<a href="${u.startsWith('http') ? u : 'https://' + u}" data-ext>${u}</a>`);
}
function toast(msg) { const t = h('div', 'toast'); t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 2600); }
const I = {
  send: '<svg viewBox="0 0 24 24"><path d="M3 20.5L21.5 12 3 3.5 5.5 11l7.5 1-7.5 1z"/></svg>',
  mic: '<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3"/></svg>',
  plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>',
  x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M7 4.5L19.5 12 7 19.5z"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><rect x="6.5" y="5" width="3.5" height="14" rx="1"/><rect x="14" y="5" width="3.5" height="14" rx="1"/></svg>',
  stop: '<svg viewBox="0 0 24 24"><rect x="6.5" y="6.5" width="11" height="11" rx="2.5"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 6.5h16M9.5 3.5h5"/><rect x="6.5" y="6.5" width="11" height="13.5" rx="1.5"/></svg>',
  reply: '<svg viewBox="0 0 24 24"><path d="M10 6l-6 6 6 6M4 12h10q6 0 6 7"/></svg>',
  more: '<svg viewBox="0 0 24 24"><circle cx="12" cy="5.5" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="12" cy="18.5" r="1.3"/></svg>',
  search: '<svg viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/></svg>',
  info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9.5"/><path d="M12 11v6M12 7.6v.1"/></svg>',
  pin: '<svg viewBox="0 0 24 24"><path d="M9 3h6l-1 7 3 3H7l3-3zM12 13v8"/></svg>',
  hide: '<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="4.5" rx="1.5"/><path d="M5 8.5V20h14V8.5M10 12.5h4"/></svg>',
  unread: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2.5"/><circle cx="18.5" cy="6" r="3" fill="currentColor"/></svg>',
  copy: '<svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4H4v12h4"/></svg>',
  fwd: '<svg viewBox="0 0 24 24"><path d="M14 6l6 6-6 6M20 12H10q-6 0-6 7"/></svg>',
  edit: '<svg viewBox="0 0 24 24"><path d="M4 20v-3.5L15.5 5 19 8.5 7.5 20z"/></svg>',
  save: '<svg viewBox="0 0 24 24"><path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/></svg>',
  smile: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.5q3.5 3 7 0M9 9.5h.01M15 9.5h.01"/></svg>',
  image: '<svg viewBox="0 0 24 24"><rect x="3" y="4.5" width="18" height="15" rx="2.5"/><path d="M3.5 17L9 11l4 4 2.5-2.5 5 5"/></svg>',
  folder: '<svg viewBox="0 0 24 24"><path d="M3 6h6.5l2 2H21v11H3z"/></svg>',
  loc: '<svg viewBox="0 0 24 24"><path d="M12 21.5C6 15 5 12.5 5 9.5a7 7 0 0 1 14 0c0 3-1 5.5-7 12z"/><circle cx="12" cy="9.5" r="2.5"/></svg>',
};

// ---------------- chat list ----------------
const FILTERS = ['Inbox', 'Unread', 'People', 'Groups', 'Hidden'];
function visibleRooms(hiddenView) {
  return [...S.rooms.values()].filter(r => !R.system(r) && R.hidden(r) === hiddenView)
    .sort((a, b) => a.pinned !== b.pinned ? (a.pinned ? -1 : 1) : b.ts - a.ts);
}
const fold = s => (s || '').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();
let shownRooms = [];
function renderList() {
  const q = fold(S.query), hv = S.filter === 4;
  const all = visibleRooms(hv), list = [], pins = [];
  let unreadCount = 0;
  for (const r of visibleRooms(false)) if (R.unread(r)) unreadCount++;
  for (const r of all) {
    if (q) { if (fold(R.name(r)).includes(q) || fold(r.preview).includes(q)) list.push(r); continue; }
    if (S.filter === 1 && !R.unread(r)) continue;
    if (S.filter === 2 && !r.dm) continue;
    if (S.filter === 3 && r.dm) continue;
    (r.pinned && S.filter === 0 ? pins : list).push(r);
  }
  shownRooms = [...pins, ...list];
  const chips = $('#chips'); chips.innerHTML = '';
  FILTERS.forEach((f, i) => {
    const c = h('button', 'chip' + (S.filter === i ? ' on' : ''), esc(f) + (i === 1 && unreadCount ? ' ' + unreadCount : ''));
    c.onclick = () => { S.filter = i; renderList(); $('#list').scrollTop = 0; };
    chips.appendChild(c);
  });
  const pe = $('#pins'); pe.innerHTML = '';
  for (const r of pins) {
    const p = h('div', 'pin' + (R.unread(r) ? ' un' : ''));
    p.appendChild(avatarEl(R.name(r), r.avatar, 56, r.dm));
    p.appendChild(h('div', 'nm', esc(R.name(r).split(' ')[0])));
    if (R.unread(r)) p.appendChild(h('div', 'dot'));
    p.onclick = () => openRoom(r.id);
    p.oncontextmenu = e => { e.preventDefault(); roomMenu(r, e.clientX, e.clientY); };
    pe.appendChild(p);
  }
  pe.style.display = pins.length ? 'flex' : 'none';
  const rows = $('#rows'); rows.innerHTML = '';
  for (const r of list) rows.appendChild(rowEl(r));
  if (!list.length && !pins.length && S.firstSync)
    rows.appendChild(h('div', '', `<div style="color:var(--dim);text-align:center;padding:40px 20px">${q ? 'No chats match “' + esc(S.query) + '”<br>Press Enter to search inside messages' : S.filter === 4 ? 'No hidden chats' : S.filter === 1 ? 'All caught up' : 'No chats'}</div>`));
  $('#status').style.display = S.firstSync ? 'none' : 'block';
  HOST.title(unreadCount ? `chat (${unreadCount})` : 'chat');
  if (S.cur) Chat.header();
}
function rowEl(r) {
  const un = R.unread(r);
  const e = h('div', 'row' + (un ? ' un' : '') + (S.cur && S.cur.id === r.id ? ' sel' : ''));
  e.appendChild(avatarEl(R.name(r), r.avatar, 48, r.dm));
  const mid = h('div', 'mid');
  const typing = R.typingText(r), draft = LS.getItem('draft_' + r.id) || '';
  const pv = typing || (draft && !(S.cur && S.cur.id === r.id) ? 'Draft: ' + draft.replace(/\n/g, ' ') : r.preview);
  mid.innerHTML = `<div class="l1"><span class="name">${esc(R.name(r))}</span>${r.pinned ? '<span class="pinmark">' + I.pin + '</span>' : ''}<span class="time">${listTime(r.ts)}</span></div>
    <div class="l2"><span class="pv${typing ? ' typing' : ''}">${esc(pv)}</span>${un ? `<span class="badge${r.unread ? '' : ' dot'}">${r.unread ? (r.unread > 99 ? '99+' : r.unread) : ''}</span>` : ''}</div>`;
  const pm = mid.querySelector('.pinmark svg'); if (pm) { pm.style.width = pm.style.height = '13px'; }
  e.appendChild(mid);
  const hov = h('div', 'hov');
  const bHide = h('button', 'ib sm', I.hide); bHide.title = R.hidden(r) ? 'Unhide' : 'Hide';
  bHide.onclick = ev => { ev.stopPropagation(); hideRoom(r, !R.hidden(r)); renderList(); };
  const bRead = h('button', 'ib sm', I.unread); bRead.title = un ? 'Mark as read' : 'Mark as unread';
  bRead.onclick = ev => { ev.stopPropagation(); un ? markRoomRead(r) : markUnread(r, true); renderList(); };
  hov.append(bRead, bHide);
  e.appendChild(hov);
  e.onclick = () => openRoom(r.id);
  e.oncontextmenu = ev => { ev.preventDefault(); roomMenu(r, ev.clientX, ev.clientY); };
  return e;
}
function popup(x, y, items, extra) {
  closePopups();
  const m = h('div', 'ctxmenu'); m.id = 'popup';
  if (extra) m.appendChild(extra);
  for (const [icon, label, fn, red] of items) {
    const b = h('button', 'mi' + (red ? ' red' : ''), icon + '<span>' + esc(label) + '</span>');
    b.onclick = () => { closePopups(); fn(); };
    m.appendChild(b);
  }
  document.body.appendChild(m);
  const rc = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - rc.width - 8) + 'px';
  m.style.top = Math.min(y, innerHeight - rc.height - 8) + 'px';
  setTimeout(() => document.addEventListener('mousedown', outside), 0);
  function outside(ev) { if (!m.contains(ev.target)) { closePopups(); document.removeEventListener('mousedown', outside); } }
  return m;
}
function closePopups() { const p = $('#popup'); if (p) p.remove(); }
function roomMenu(r, x, y) {
  const un = R.unread(r), hid = R.hidden(r);
  popup(x, y, [
    [I.pin, r.pinned ? 'Unpin' : 'Pin', () => { pinRoom(r, !r.pinned); renderList(); }],
    [I.unread, un ? 'Mark as read' : 'Mark as unread', () => { un ? markRoomRead(r) : markUnread(r, true); renderList(); }],
    [I.hide, hid ? 'Unhide' : 'Hide', () => { hideRoom(r, !hid); renderList(); }],
  ]);
}
function openRoom(id, eventId) {
  S.cur = R.get(id);
  Chat.open(S.cur, eventId);
  renderList();
}
function moveRoom(dir) {
  if (!shownRooms.length) return;
  let i = S.cur ? shownRooms.findIndex(r => r.id === S.cur.id) : -1;
  i = Math.max(0, Math.min(shownRooms.length - 1, i + dir));
  openRoom(shownRooms[i].id);
}

// ---------------- conversation ----------------
const revealed = new Set();
const Chat = {
  raw: new Map(), msgs: [], byId: new Map(), pending: [], older: null, newer: null, noMore: false, loading: false,
  ctxMode: false, replyTo: null, editing: null, showMeta: new Set(), divider: null, flash: null, player: null, playing: null, speed: 1,

  open(r, eventId) {
    const prev = this.room;
    if (prev && prev.id !== r.id) { LS.setItem('draft_' + prev.id, $('#inp').value); if (!$('#inp').value) LS.removeItem('draft_' + prev.id); typing(false); }
    this.room = r; this.raw = new Map(); this.pending = []; this.older = null; this.newer = null; this.noMore = false; this.ctxMode = false;
    this.replyTo = null; this.editing = null; this.showMeta.clear(); this.divider = null; this.firstLoad = true; this.stopAudio();
    $('#empty').style.display = 'none'; $('#conv').style.display = 'flex';
    $('#chatSearch').style.display = 'none';
    $('#inp').value = LS.getItem('draft_' + r.id) || ''; autosize(); updateSend(); this.ctx();
    $('#msgs').innerHTML = '';
    this.header();
    if (!$('#info').style.display || $('#info').style.display === 'none') {} else Info.render();
    if (eventId) { this.firstLoad = false; this.jump(eventId); } else this.loadOlder();
    $('#inp').focus();
  },
  header() {
    const r = this.room; if (!r) return;
    const hd = $('#head'); hd.innerHTML = '';
    hd.appendChild(avatarEl(R.name(r), r.avatar, 40, r.dm));
    const tt = h('div', 'tt');
    const t = R.typingText(r);
    tt.innerHTML = `<div class="t1">${esc(R.name(r))}</div><div class="t2">${esc(t || (r.dm ? 'WhatsApp' : Math.max(0, r.joined - 1) + ' people'))}</div>`;
    tt.onclick = () => Info.toggle();
    hd.appendChild(tt);
    const s = h('button', 'ib', I.search); s.title = 'Search this chat (Ctrl+F)'; s.onclick = () => this.toggleSearch(true);
    const i = h('button', 'ib', I.info); i.title = 'Chat info'; i.onclick = () => Info.toggle();
    hd.append(s, i);
  },
  async page(dir, from) {
    const r = await api('GET', roomPath(this.room.id) + '/messages?dir=' + dir + '&limit=60&filter=' + enc('{"lazy_load_members":true}') + (from ? '&from=' + enc(from) : ''));
    if (r.code !== 200) throw new Error('HTTP ' + r.code);
    applyState(this.room, r.json.state || []);
    for (const e of r.json.chunk || []) this.raw.set(e.event_id, e);
    return r.json;
  },
  async loadOlder() {
    if (this.loading || this.noMore) return;
    this.loading = true;
    const room = this.room, box = $('#msgs');
    const prevH = box.scrollHeight, prevTop = box.scrollTop, from = this.older;
    try {
      const j = await this.page('b', from);
      if (room !== this.room) return;
      this.older = j.end || null;
      if (!j.end || !(j.chunk || []).length) this.noMore = true;
      if (this.firstLoad) {
        this.firstLoad = false;
        this.rebuild();
        const unread = room.unread; let seen = 0;
        for (let k = this.msgs.length - 1; k >= 0 && unread > 0; k--) if (!this.msgs[k].mine && ++seen === unread) { this.divider = this.msgs[k].id; break; }
        this.render(); box.scrollTop = box.scrollHeight;
        this.markLatest();
        if (box.scrollHeight <= box.clientHeight + 40 && !this.noMore) { this.loading = false; return this.loadOlder(); }
      } else {
        this.rebuild(); this.render();
        box.scrollTop = box.scrollHeight - prevH + prevTop;
      }
    } catch (e) {} finally { this.loading = false; }
  },
  async loadNewer() {
    if (this.loading || !this.newer) return;
    this.loading = true;
    try {
      const j = await this.page('f', this.newer);
      this.newer = (j.chunk || []).length ? j.end : null;
      if (!this.newer) this.ctxMode = false;
      this.rebuild(); this.render(true);
    } catch (e) {} finally { this.loading = false; }
  },
  async jump(eventId) {
    if (this.byId.has(eventId)) return this.scrollTo(eventId);
    const r = await api('GET', roomPath(this.room.id) + '/context/' + enc(eventId) + '?limit=40&filter=' + enc('{"lazy_load_members":true}'));
    if (r.code !== 200) return toast('Couldn’t open that message');
    const j = r.json;
    this.raw = new Map(); this.pending = [];
    for (const e of [...(j.events_before || []), ...(j.events_after || [])]) this.raw.set(e.event_id, e);
    if (j.event) this.raw.set(j.event.event_id, j.event);
    applyState(this.room, j.state || []);
    this.older = j.start || null; this.newer = j.end || null; this.noMore = !this.older; this.ctxMode = true; this.divider = null;
    this.rebuild(); this.render(); this.scrollTo(eventId);
  },
  scrollTo(id) {
    const el = document.querySelector(`.m[data-id="${CSS.escape(id)}"]`);
    if (!el) return;
    el.scrollIntoView({ block: 'center' });
    el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1600);
  },
  toBottom() {
    if (this.ctxMode) { this.ctxMode = false; this.raw = new Map(); this.older = null; this.newer = null; this.noMore = false; this.firstLoad = true; $('#msgs').innerHTML = ''; this.loadOlder(); }
    else { const b = $('#msgs'); b.scrollTop = b.scrollHeight; }
  },
  onEvents(evs) {
    this.header();
    if (this.ctxMode) return;
    const box = $('#msgs'), atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    for (const e of evs) this.raw.set(e.event_id, e);
    this.rebuild(); this.render(atBottom);
    if (evs.length && document.hasFocus()) this.markLatest();
  },
  markLatest() {
    for (let k = this.msgs.length - 1; k >= 0; k--) { const m = this.msgs[k]; if (m.id && !m.id.startsWith('~')) { markRead(this.room.id, m.id); return; } }
  },
  rebuild() {
    const evs = [...this.raw.values()].sort((a, b) => (a.origin_server_ts || 0) - (b.origin_server_ts || 0));
    const out = []; this.byId = new Map();
    for (const e of evs) {
      if (e.type !== 'm.room.message') continue;
      const c = e.content || {}, rel = c['m.relates_to'];
      if (rel && rel.rel_type === 'm.replace') continue;
      if (isSticker(c)) continue;
      const u = e.unsigned || {};
      const m = { id: e.event_id, sender: e.sender, mine: e.sender === S.me, ts: e.origin_server_ts || 0, txn: u.transaction_id, reactions: new Map(), my: new Map(),
        replyTo: rel && rel['m.in_reply_to'] ? rel['m.in_reply_to'].event_id : null };
      if (!Object.keys(c).length || u.redacted_because) m.redacted = true; else fill(m, c);
      out.push(m); this.byId.set(m.id, m);
    }
    for (const e of evs) {
      const c = e.content || {}, gone = e.unsigned && e.unsigned.redacted_because;
      if (e.type === 'm.reaction') {
        const rel = c['m.relates_to']; if (!rel || gone) continue;
        const m = this.byId.get(rel.event_id); if (!m) continue;
        m.reactions.set(rel.key, (m.reactions.get(rel.key) || 0) + 1);
        if (e.sender === S.me) m.my.set(rel.key, e.event_id);
      } else if (e.type === 'm.room.message') {
        const rel = c['m.relates_to']; if (!rel || rel.rel_type !== 'm.replace') continue;
        const m = this.byId.get(rel.event_id), nc = c['m.new_content']; if (!m || !nc) continue;
        const keep = m.replyTo; fill(m, nc); m.replyTo = keep; m.edited = true;
        if (isStickerNotice(nc)) m.sticker = true;
      } else if (e.type === 'm.room.redaction') {
        const m = this.byId.get(e.redacts || c.redacts); if (m) m.redacted = true;
      } else if (e.type === 'com.beeper.message_send_status') {
        const rel = c['m.relates_to'], m = rel && this.byId.get(rel.event_id); if (!m) continue;
        m.status = c.status; m.statusReason = c.message || c.reason || '';
      }
    }
    this.msgs = out.filter(m => !m.sticker);
    this.pending = this.pending.filter(p => !this.msgs.some(m => (p.txn && p.txn === m.txn) || p.id === m.id));
    this.msgs.push(...this.pending);
  },
  statusText(m) {
    if (m.failed) return 'Not sent';
    if (m.pending || !m.id || m.id.startsWith('~')) return 'Sending…';
    if (m.status && m.status !== 'SUCCESS') return 'Not delivered to WhatsApp';
    return R.readAt(this.room, m.ts) ? 'Read' : 'Sent';
  },
  render(stick) {
    const box = $('#msgs'), r = this.room;
    const keepBottom = stick === true || box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    box.innerHTML = '';
    let prevTs = 0, prev = null;
    const msgs = this.msgs;
    msgs.forEach((m, i) => {
      if (!prevTs || !sameDay(prevTs, m.ts)) { box.appendChild(h('div', 'day', esc(dayLabel(m.ts)))); prev = null; }
      if (m.id === this.divider) box.appendChild(h('div', 'newdiv', 'New messages'));
      const next = msgs[i + 1] && sameDay(msgs[i + 1].ts, m.ts) ? msgs[i + 1] : null;
      const first = !prev || prev.sender !== m.sender || m.ts - prev.ts > 300000;
      const last = !next || next.sender !== m.sender || next.ts - m.ts > 300000;
      box.appendChild(this.msgEl(m, first, last));
      prevTs = m.ts; prev = m;
    });
    const lastM = msgs[msgs.length - 1];
    if (lastM && lastM.mine && !this.ctxMode) {
      const st = this.statusText(lastM), s = h('div', 'status' + (st === 'Not sent' ? ' fail' : ''), esc(st));
      if (st === 'Not sent') s.onclick = () => this.doSend(lastM);
      box.appendChild(s);
    }
    if (r.typing.length && !this.ctxMode) box.appendChild(h('div', 'typingb', '<i></i><i></i><i></i>'));
    if (keepBottom) box.scrollTop = box.scrollHeight;
    updateDown();
  },
  msgEl(m, first, last) {
    const r = this.room, group = !r.dm;
    const e = h('div', 'm' + (m.mine ? ' mine' : '') + (first ? ' first' : '') + (last ? ' last' : '') + (this.showMeta.has(m.id) ? ' showmeta' : ''));
    e.dataset.id = m.id || '';
    if (group && !m.mine) e.appendChild(avatarEl(R.nameOf(r, m.sender), null, 30, true)).classList.add('sav');
    const col = h('div', 'col');
    if (group && !m.mine && first) col.appendChild(h('div', 'sender', esc(R.nameOf(r, m.sender))));
    col.appendChild(this.bubble(m, last));
    if (m.reactions.size) {
      const rs = h('div', 'reacts');
      for (const [k, n] of m.reactions) {
        const c = h('span', 'rc' + (m.my.has(k) ? ' me' : ''), esc(k) + (n > 1 ? ' ' + n : ''));
        c.onclick = () => this.react(m, k);
        rs.appendChild(c);
      }
      col.appendChild(rs);
    }
    const meta = h('div', 'meta' + (m.failed ? ' fail' : ''), m.failed ? 'Not sent · click to retry' : esc(clock(m.ts) + (m.edited ? ' · Edited' : '') + (m.mine ? ' · ' + this.statusText(m) : '')));
    if (m.failed) meta.onclick = () => this.doSend(m);
    col.appendChild(meta);
    e.appendChild(col);
    e.appendChild(h('div', 'hovtime', esc(clock(m.ts))));
    if (!m.pending && m.id && !m.id.startsWith('~') && !m.redacted) {
      const tool = h('div', 'tool');
      const q = h('button', 'q', esc(quick())); q.title = 'React ' + quick(); q.onclick = () => this.react(m, quick());
      const rp = h('button', 'q', I.reply); rp.title = 'Reply'; rp.onclick = () => this.startReply(m);
      const mo = h('button', 'q', I.more); mo.title = 'More'; mo.onclick = ev => this.menu(m, ev.clientX, ev.clientY);
      tool.append(q, rp, mo);
      e.appendChild(tool);
      e.oncontextmenu = ev => { ev.preventDefault(); this.menu(m, ev.clientX, ev.clientY); };
      e.querySelector('.col').ondblclick = ev => { ev.preventDefault(); getSelection().removeAllRanges(); this.react(m, quick()); };
    }
    return e;
  },
  bubble(m, last) {
    const autop = prefs.get('autophotos', false);
    if (!m.redacted && m.msgtype === 'm.image' && m.mxc) {
      const wrap = h('div', '');
      if (m.replyTo) wrap.appendChild(this.quote(m.replyTo));
      const w = 300, ht = m.w && m.h ? Math.max(90, Math.min(Math.round(w * m.h / m.w), 380)) : 220;
      const p = h('div', 'photo'); p.style.width = w + 'px'; p.style.height = ht + 'px';
      const show = revealed.has(m.mxc) || autop;
      if (show) { const img = new Image(); img.src = media(m.mxc, 800); img.alt = ''; p.appendChild(img); }
      else p.innerHTML = I.image + '<span>Click to load photo</span>';
      p.onclick = () => { if (revealed.has(m.mxc) || autop) Viewer.show(m); else { revealed.add(m.mxc); this.render(); } };
      wrap.appendChild(p);
      if (m.body && !/\.(jpe?g|png|webp|gif|heic)$/i.test(m.body)) { const c = h('div', 'b cap'); c.innerHTML = linkify(m.body); wrap.appendChild(c); }
      return wrap;
    }
    if (!m.redacted && m.msgtype === 'm.text' && !m.replyTo && emojiOnly(m.body)) return h('div', 'emo', esc(m.body.trim()));
    const b = h('div', 'b' + (m.notice ? ' notice' : '') + (m.redacted ? ' del' : ''));
    if (m.replyTo && !m.redacted) b.appendChild(this.quote(m.replyTo));
    if (m.redacted) { b.appendChild(document.createTextNode('Deleted message')); return b; }
    if (m.msgtype === 'm.audio' && m.mxc) { b.appendChild(this.voice(m)); const tr = transcriptEl(m); if (tr) b.appendChild(tr); return b; }
    if (m.msgtype === 'm.location' && m.geo) {
      const coords = m.geo.replace(/^geo:/, '').split(/[;?]/)[0];
      const f = h('div', 'file', I.loc + `<div><div>Location</div><div class="sub">${esc(coords)} · click to open map</div></div>`);
      f.onclick = () => HOST.open(`https://www.openstreetmap.org/?mlat=${coords.split(',')[0]}&mlon=${coords.split(',')[1]}#map=17/${coords.split(',')[0]}/${coords.split(',')[1]}`);
      b.appendChild(f); return b;
    }
    if ((m.msgtype === 'm.video' || m.msgtype === 'm.file') && m.mxc) {
      const f = h('div', 'file', (m.msgtype === 'm.video' ? I.play : I.folder) + `<div><div>${esc(m.body)}</div><div class="sub">${m.msgtype === 'm.video' ? 'Video' : 'File'} · click to save</div></div>`);
      f.onclick = () => save(m);
      b.appendChild(f); return b;
    }
    const t = h('span', ''); t.innerHTML = linkify(m.body || '');
    b.appendChild(t);
    b.onclick = ev => { if (ev.target.closest('a')) return; if (this.showMeta.has(m.id)) this.showMeta.delete(m.id); else this.showMeta.add(m.id); this.render(); };
    return b;
  },
  quote(id) {
    const t = this.byId.get(id);
    const q = h('div', 'quote', `<div class="who">${esc(t ? (t.mine ? 'You' : R.nameOf(this.room, t.sender)) : 'Reply')}</div><div class="what">${esc(t ? summary(t) : 'Click to view')}</div>`);
    q.onclick = ev => { ev.stopPropagation(); this.jump(id); };
    return q;
  },
  voice(m) {
    const v = h('div', 'voice'), playing = this.playing === m.id;
    const pb = h('button', 'pb', playing && this.player && !this.player.paused ? I.pause : I.play);
    pb.onclick = () => this.togglePlay(m);
    const bars = h('div', 'bars');
    const wf = waveOf(m), prog = playing && this.player && m.durMs ? this.player.currentTime * 1000 / m.durMs : 0;
    for (let k = 0; k < 32; k++) {
      const val = wf[Math.floor(k * wf.length / 32)] || 0;
      const i = h('i', k / 32 < prog ? 'on' : ''); i.style.height = Math.max(12, Math.sqrt(Math.min(1024, val) / 1024) * 100) + '%';
      bars.appendChild(i);
    }
    bars.onclick = ev => {
      const frac = (ev.clientX - bars.getBoundingClientRect().left) / bars.clientWidth;
      if (this.playing !== m.id) this.togglePlay(m, frac); else if (this.player) this.player.currentTime = frac * (this.player.duration || m.durMs / 1000);
    };
    const vt = h('span', 'vt', playing && this.player ? timer(this.player.currentTime * 1000) : timer(m.durMs));
    v.append(pb, bars, vt);
    if (playing) { const sp = h('span', 'spd', this.speed + '×'); sp.onclick = () => { this.speed = this.speed === 1 ? 1.5 : this.speed === 1.5 ? 2 : 1; if (this.player) this.player.playbackRate = this.speed; this.render(); }; v.appendChild(sp); }
    return v;
  },
  togglePlay(m, frac) {
    if (this.playing === m.id && this.player) { this.player.paused ? this.player.play() : this.player.pause(); this.render(); return; }
    this.stopAudio();
    const a = new Audio(media(m.mxc));
    a.playbackRate = this.speed;
    this.player = a; this.playing = m.id;
    a.onloadedmetadata = () => { if (frac) a.currentTime = frac * a.duration; };
    a.ontimeupdate = () => { if (this.playing === m.id) this.renderVoice(m); };
    a.onended = () => { this.stopAudio(); this.render(); };
    a.onerror = () => { toast('Couldn’t play that audio'); this.stopAudio(); this.render(); };
    a.play().catch(() => {});
    this.render();
  },
  renderVoice(m) {
    const el = document.querySelector(`.m[data-id="${CSS.escape(m.id)}"] .voice`);
    if (el) el.replaceWith(this.voice(m));
  },
  stopAudio() { if (this.player) { this.player.pause(); this.player.src = ''; } this.player = null; this.playing = null; },
  react(m, key) {
    if (!m.id || m.id.startsWith('~')) return;
    const mine = m.my.get(key);
    if (mine) return redact(this.room.id, mine);
    bg(() => sendContent(this.room.id, 'm.reaction', { 'm.relates_to': { rel_type: 'm.annotation', event_id: m.id, key } }));
  },
  menu(m, x, y) {
    const react = h('div', 'ereact');
    const keys = [...new Set([quick(), ...QUICK])].slice(0, 6);
    for (const k of keys) { const b = h('button', m.my.has(k) ? 'me' : '', esc(k)); b.onclick = () => { closePopups(); this.react(m, k); }; react.appendChild(b); }
    const more = h('button', '', '＋'); more.title = 'More reactions'; more.onclick = () => { closePopups(); emojiPicker(x, y, k => this.react(m, k)); }; react.appendChild(more);
    const items = [[I.reply, 'Reply', () => this.startReply(m)]];
    if (m.body && !m.mxc) items.push([I.copy, 'Copy', () => { navigator.clipboard.writeText(m.body); toast('Copied'); }]);
    if (m.content && !m.notice) items.push([I.fwd, 'Forward', () => forward(m)]);
    if (m.mine && m.msgtype === 'm.text') items.push([I.edit, 'Edit', () => this.startEdit(m)]);
    if (m.mxc) items.push([I.save, 'Save', () => save(m)]);
    items.push([I.info, 'Info', () => msgInfo(m)]);
    if (m.mine) items.push([I.trash, 'Delete for everyone', () => { if (confirm('Delete this message for everyone?')) { m.redacted = true; this.render(); redact(this.room.id, m.id); } }, true]);
    popup(x, y, items, react);
  },
  startReply(m) { this.replyTo = m; this.editing = null; this.ctx(); $('#inp').focus(); },
  startEdit(m) { this.editing = m; this.replyTo = null; $('#inp').value = m.body; autosize(); this.ctx(); updateSend(); $('#inp').focus(); },
  ctx() {
    const c = $('#ctx'), m = this.editing || this.replyTo;
    c.style.display = m ? 'flex' : 'none';
    if (m) c.querySelector('span').textContent = this.editing ? 'Editing message' : 'Replying to ' + (m.mine ? 'yourself' : R.nameOf(this.room, m.sender)) + ': ' + summary(m);
  },
  toggleSearch(show) {
    $('#chatSearch').style.display = show ? 'block' : 'none';
    if (show) $('#cq').focus(); else $('#inp').focus();
  },
  async search(term) {
    if (!term) return;
    const r = await api('POST', '/_matrix/client/v3/search', { search_categories: { room_events: { search_term: term, order_by: 'recent', filter: { rooms: [this.room.id] } } } });
    const res = (((r.json.search_categories || {}).room_events || {}).results || []).map(x => x.result).filter(Boolean);
    if (!res.length) return toast('Nothing found');
    const rc = $('#chatSearch').getBoundingClientRect();
    popup(rc.left + 14, rc.bottom, res.slice(0, 20).map(ev => ['', listTime(ev.origin_server_ts) + ' · ' + (ev.sender === S.me ? 'You' : R.nameOf(this.room, ev.sender)) + ': ' + ((ev.content || {}).body || '').slice(0, 80), () => { this.toggleSearch(false); this.jump(ev.event_id); }]));
  },
  // sending
  async send() {
    const text = $('#inp').value;
    if (!text.trim()) return;
    $('#inp').value = ''; autosize(); updateSend(); LS.removeItem('draft_' + this.room.id); clearRemoteDraft(this.room.id); typing(false);
    if (this.editing) {
      const t = this.editing; this.editing = null; this.ctx();
      t.body = text; t.edited = true; this.render();
      return bg(() => sendContent(this.room.id, 'm.room.message', { msgtype: 'm.text', body: '* ' + text, 'm.new_content': { msgtype: 'm.text', body: text }, 'm.relates_to': { rel_type: 'm.replace', event_id: t.id } }));
    }
    const c = { msgtype: 'm.text', body: text };
    const rp = this.replyTo;
    if (rp) c['m.relates_to'] = { 'm.in_reply_to': { event_id: rp.id } };
    this.replyTo = null; this.ctx();
    this.echo(c, rp && rp.id);
  },
  echo(content, replyId) {
    const txn = 'd' + Date.now() + Math.random().toString(36).slice(2, 8);
    const m = { id: '~' + txn, txn, sender: S.me, mine: true, pending: true, ts: Date.now(), reactions: new Map(), my: new Map(), replyTo: replyId, retry: content };
    fill(m, content); m.replyTo = replyId;
    this.pending.push(m);
    if (this.ctxMode) this.toBottom();
    this.rebuild(); this.render(true);
    this.doSend(m);
  },
  async doSend(m) {
    m.failed = false; m.pending = true;
    try { const id = await sendContent(this.room.id, 'm.room.message', m.retry, m.txn); m.id = id; m.pending = false; }
    catch (e) { m.failed = true; m.pending = false; if (TEST) toast(e.message); }
    this.rebuild(); this.render();
  },
  async upload(file) {
    const mime = file.type || 'application/octet-stream';
    if (file.size > 95 * 1024 * 1024) return toast(file.name + ' is too big (max ~95 MB)');
    const msgtype = mime.startsWith('image/') ? 'm.image' : mime.startsWith('video/') ? 'm.video' : mime.startsWith('audio/') ? 'm.audio' : 'm.file';
    const room = this.room, rp = this.replyTo; this.replyTo = null; this.ctx();
    const ph = { id: '~u' + Date.now(), sender: S.me, mine: true, pending: true, ts: Date.now(), msgtype: 'm.notice', notice: true, body: 'Sending ' + file.name + '…', reactions: new Map(), my: new Map() };
    this.pending.push(ph); this.rebuild(); this.render(true);
    try {
      if (TEST) throw new Error('test mode: not uploading');
      const info = { mimetype: mime, size: file.size };
      if (msgtype === 'm.image') { const bmp = await createImageBitmap(file).catch(() => null); if (bmp) { info.w = bmp.width; info.h = bmp.height; } }
      const up = await api('POST', '/_matrix/media/v3/upload?filename=' + enc(file.name), file, { ctype: mime, timeout: 180000 });
      if (up.code !== 200) throw new Error(up.json.error || 'upload HTTP ' + up.code);
      const c = { msgtype, body: file.name, url: up.json.content_uri, info };
      if (rp) c['m.relates_to'] = { 'm.in_reply_to': { event_id: rp.id } };
      if (msgtype === 'm.image') revealed.add(up.json.content_uri);
      this.pending = this.pending.filter(p => p !== ph);
      if (room === this.room) this.echo(c, rp && rp.id); else bg(() => sendContent(room.id, 'm.room.message', c));
    } catch (e) { this.pending = this.pending.filter(p => p !== ph); this.rebuild(); this.render(); toast('Upload failed: ' + e.message); }
  },
};
// ---------------- voice-note transcripts (server: faster-whisper large-v3-turbo) ----------------
const TX = { text: new Map(), state: new Map() };
async function transcribe(mxc, retry) {
  if (TX.text.has(mxc) || TX.state.get(mxc) === 'pending') return;
  TX.state.set(mxc, 'pending');
  let ok = false;
  try {
    for (let i = 0; i < 80; i++) {
      const r = await api('GET', TRANSCRIBER + '/t?mxc=' + enc(mxc) + (retry && !i ? '&retry=1' : ''), null, { timeout: 30000 });
      if (r.code !== 200) break;
      if (r.json.status === 'done') { TX.text.set(mxc, r.json.text || ''); TX.state.delete(mxc); ok = true; break; }
      if (r.json.status === 'error') break;
      await sleep(3000);
    }
  } catch (e) {}
  if (!ok) TX.state.set(mxc, 'error');
  if (Chat.room) Chat.render();
}
function transcriptEl(m) {
  if (!m.mxc || m.pending) return null;
  const t = TX.text.get(m.mxc), st = TX.state.get(m.mxc);
  if (t !== undefined) { const d = h('div', 'tr' + (t ? '' : ' dim')); d.textContent = t || 'No speech'; return d; }
  if (st === 'pending') return h('div', 'tr dim', 'Transcribing…');
  if (st === 'error') { const d = h('div', 'tr dim click', 'Couldn’t transcribe · click to retry'); d.onclick = ev => { ev.stopPropagation(); TX.state.delete(m.mxc); transcribe(m.mxc, true); Chat.render(); }; return d; }
  if (prefs.get('transcribe', true)) { transcribe(m.mxc); return h('div', 'tr dim', 'Transcribing…'); }
  const d = h('div', 'tr dim click', 'Click to transcribe'); d.onclick = ev => { ev.stopPropagation(); transcribe(m.mxc); Chat.render(); };
  return d;
}

function fill(m, c) {
  m.content = c; m.msgtype = c.msgtype; m.body = c.body || ''; m.notice = c.msgtype === 'm.notice'; m.mxc = c.url || null;
  m.voice = !!c['org.matrix.msc3245.voice']; m.geo = c.geo_uri || null;
  const info = c.info || {}; m.durMs = info.duration || 0; m.w = info.w || 0; m.h = info.h || 0;
  if (c['m.relates_to'] && m.body.startsWith('> ')) { const i = m.body.indexOf('\n\n'); if (i > 0) m.body = m.body.slice(i + 2); }
  if (m.notice && m.body.startsWith('* ')) m.body = m.body.slice(2);
}
function summary(m) {
  if (m.redacted) return 'Deleted message';
  const s = previewText({ msgtype: m.msgtype, body: m.body, 'org.matrix.msc3245.voice': m.voice ? {} : undefined });
  return s ? s[0].toUpperCase() + s.slice(1) : '';
}
function waveOf(m) {
  const a = m.content && m.content['org.matrix.msc1767.audio'];
  if (a && Array.isArray(a.waveform) && a.waveform.length) return a.waveform;
  let seed = 7; for (const ch of m.id || 'x') seed = (seed * 31 + ch.charCodeAt(0)) | 0;
  const out = []; for (let k = 0; k < 32; k++) { seed = (seed * 1103515245 + 12345) | 0; out.push(250 + Math.abs(seed >> 16) % 600); }
  return out;
}
const quick = () => prefs.get('quick', '❤️');
function redact(roomId, id) { if (!TEST) bg(() => api('PUT', roomPath(roomId) + '/redact/' + enc(id) + '/r' + Date.now(), {})); }
function save(m) {
  const a = document.createElement('a');
  fetch(media(m.mxc), { headers: { Authorization: 'Bearer ' + S.token } }).then(r => r.blob()).then(b => {
    a.href = URL.createObjectURL(b); a.download = m.body || 'file'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 10000); toast('Saved to Downloads');
  }).catch(() => toast('Save failed'));
}
function msgInfo(m) {
  const lines = [m.mine ? 'Sent by you' : 'From ' + R.nameOf(Chat.room, m.sender), new Date(m.ts).toLocaleString('en-GB')];
  if (m.edited) lines.push('Edited');
  if (m.mine) lines.push(Chat.statusText(m));
  if (m.statusReason) lines.push(m.statusReason);
  if (m.reactions.size) lines.push('Reactions: ' + [...m.reactions.keys()].join(' '));
  alert(lines.join('\n'));
}
function emojiPicker(x, y, pick) {
  const g = h('div', 'egrid');
  for (const k of EMOJI) { const b = h('button', '', k); b.onclick = () => { closePopups(); pick(k); }; g.appendChild(b); }
  popup(x, y, [], g);
}
function forward(m) {
  const box = h('div', '');
  const list = visibleRooms(false).slice(0, 60);
  modal('Forward to', box);
  for (const r of list) {
    const row = h('div', 'nc'); row.appendChild(avatarEl(R.name(r), r.avatar, 36, r.dm)); row.appendChild(h('div', '', esc(R.name(r))));
    row.onclick = () => {
      const c = JSON.parse(JSON.stringify(m.content)); delete c['m.relates_to']; delete c['m.new_content'];
      bg(() => sendContent(r.id, 'm.room.message', c)); closeModal(); toast('Forwarded to ' + R.name(r));
    };
    box.appendChild(row);
  }
}

// ---------------- composer ----------------
function autosize() { const t = $('#inp'); t.style.height = '44px'; t.style.height = Math.min(200, t.scrollHeight) + 'px'; }
function updateSend() {
  const has = $('#inp').value.trim().length > 0 || Chat.editing;
  const s = $('#send'); s.className = has ? 'go' : ''; s.innerHTML = has ? I.send : I.mic; s.title = has ? 'Send (Enter)' : 'Record voice message';
}
function updateDown() {
  const b = $('#msgs'), d = $('#down');
  d.style.display = (b.scrollHeight - b.scrollTop - b.clientHeight > 300 || Chat.ctxMode) ? 'flex' : 'none';
}

// ---------------- voice recorder (pause/resume, waveform, stop → replay/send) ----------------
const Rec = {
  mr: null, chunks: [], stream: null, paused: false, acc: 0, seg: 0, amps: [], blob: null, dur: 0, audio: null, analyser: null, raf: 0,
  elapsed() { return this.acc + (this.mr && this.mr.state === 'recording' ? Date.now() - this.seg : 0); },
  async start() {
    try { this.stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) { return toast('No microphone available (' + e.name + ')'); }
    const type = MediaRecorder.isTypeSupported('audio/ogg;codecs=opus') ? 'audio/ogg;codecs=opus' : 'audio/webm;codecs=opus';
    this.mr = new MediaRecorder(this.stream, { mimeType: type, audioBitsPerSecond: 32000 });
    this.chunks = []; this.amps = []; this.acc = 0; this.seg = Date.now(); this.paused = false; this.blob = null;
    this.mr.ondataavailable = e => { if (e.data.size) this.chunks.push(e.data); };
    this.mr.start(250);
    const ac = new AudioContext(), src = ac.createMediaStreamSource(this.stream);
    this.analyser = ac.createAnalyser(); this.analyser.fftSize = 512; src.connect(this.analyser); this.ac = ac;
    this.ui(); this.loop();
  },
  loop() {
    cancelAnimationFrame(this.raf);
    const tick = () => {
      if (this.mr && this.mr.state === 'recording') {
        const d = new Uint8Array(this.analyser.fftSize); this.analyser.getByteTimeDomainData(d);
        let pk = 0; for (const v of d) pk = Math.max(pk, Math.abs(v - 128));
        if (!this._last || Date.now() - this._last > 90) { this.amps.push(Math.min(32767, pk * 256)); this._last = Date.now(); }
      }
      this.draw();
      $('#rtime').textContent = this.blob ? timer(this.audio && !this.audio.paused ? this.audio.currentTime * 1000 : this.dur) : timer(this.elapsed());
      if (this.mr || (this.audio && !this.audio.paused)) this.raf = requestAnimationFrame(tick);
    };
    this.raf = requestAnimationFrame(tick);
  },
  draw() {
    const c = $('#wave'), w = c.clientWidth, ht = c.clientHeight;
    c.width = w * devicePixelRatio; c.height = ht * devicePixelRatio;
    const g = c.getContext('2d'); g.scale(devicePixelRatio, devicePixelRatio);
    const step = 4, bars = Math.floor(w / step), n = this.amps.length;
    const played = this.blob && this.audio && this.dur ? this.audio.currentTime * 1000 / this.dur : -1;
    g.lineCap = 'round'; g.lineWidth = 2;
    for (let i = 0; i < bars; i++) {
      const idx = this.blob ? Math.floor(i * n / bars) : n - bars + i;
      const a = idx >= 0 && idx < n ? this.amps[idx] / 32767 : 0;
      const bh = Math.max(2, Math.sqrt(a) * ht);
      g.strokeStyle = this.blob ? (played >= 0 && i / bars <= played ? '#f2f2f2' : '#777') : '#f2f2f2';
      g.beginPath(); g.moveTo(i * step + 2, ht / 2 - bh / 2); g.lineTo(i * step + 2, ht / 2 + bh / 2); g.stroke();
    }
  },
  pause() {
    if (this.blob) { // preview play/pause
      if (!this.audio) { this.audio = new Audio(URL.createObjectURL(this.blob)); this.audio.onended = () => { this.ui(); }; }
      this.audio.paused ? this.audio.play() : this.audio.pause();
      this.ui(); this.loop(); return;
    }
    if (!this.mr) return;
    if (this.mr.state === 'recording') { this.mr.pause(); this.acc += Date.now() - this.seg; this.paused = true; }
    else { this.mr.resume(); this.seg = Date.now(); this.paused = false; }
    this.ui();
  },
  async finish() {
    if (!this.mr) return;
    this.dur = this.elapsed();
    const mr = this.mr;
    await new Promise(r => { mr.onstop = r; mr.stop(); });
    this.cleanupStream();
    this.mr = null;
    if (this.dur < 700) return this.cancel();
    this.blob = new Blob(this.chunks, { type: mr.mimeType });
    this.ui(); this.loop();
  },
  cleanupStream() { if (this.stream) this.stream.getTracks().forEach(t => t.stop()); this.stream = null; if (this.ac) this.ac.close(); this.ac = null; },
  cancel() {
    if (this.mr) { try { this.mr.stop(); } catch (e) {} this.mr = null; }
    this.cleanupStream();
    if (this.audio) this.audio.pause();
    this.audio = null; this.blob = null; this.ui();
  },
  async send() {
    const blob = this.blob, dur = this.dur, amps = this.amps.slice();
    if (this.audio) this.audio.pause();
    this.audio = null; this.blob = null; this.ui();
    try {
      let bytes = new Uint8Array(await blob.arrayBuffer());
      if (!blob.type.includes('ogg')) {
        if (!HOST.remux) throw new Error('can’t convert WebM to Ogg here');
        bytes = new Uint8Array(await HOST.remux(bytes));
      }
      if (TEST) throw new Error('test mode: not uploading');
      const up = await api('POST', '/_matrix/media/v3/upload?filename=voice.ogg', bytes, { ctype: 'audio/ogg', timeout: 120000 });
      if (up.code !== 200) throw new Error(up.json.error || 'upload HTTP ' + up.code);
      const n = amps.length, wf = [];
      for (let k = 0; k < Math.min(n, 60); k++) wf.push(Math.min(1024, Math.round(amps[n <= 60 ? k : Math.floor(k * n / 60)] * 1024 / 32767)));
      Chat.echo({ msgtype: 'm.audio', body: 'Voice message', url: up.json.content_uri, info: { mimetype: 'audio/ogg', size: bytes.length, duration: dur },
        'org.matrix.msc1767.audio': { duration: dur, waveform: wf }, 'org.matrix.msc3245.voice': {} });
    } catch (e) { toast('Voice message failed: ' + e.message); }
  },
  ui() {
    const on = !!(this.mr || this.blob);
    $('#rec').style.display = on ? 'flex' : 'none';
    $('#pill').style.display = on ? 'none' : 'flex';
    $('#plus').innerHTML = on ? I.trash : I.plus; $('#plus').title = on ? 'Discard' : 'Attach';
    const recording = this.mr && this.mr.state === 'recording';
    $('#rpause').innerHTML = this.blob ? (this.audio && !this.audio.paused ? I.pause : I.play) : recording ? I.pause : I.mic;
    $('#rpause').title = this.blob ? 'Listen' : recording ? 'Pause' : 'Resume';
    $('#ract').innerHTML = this.blob ? I.send : I.stop; $('#ract').title = this.blob ? 'Send' : 'Stop';
    $('#rtime').style.opacity = this.paused && !this.blob ? 0.55 : 1;
  },
};

// ---------------- attach (files, paste, drag & drop) ----------------
function attachMenu() {
  const r = $('#plus').getBoundingClientRect();
  popup(r.left, r.top - 150, [
    [I.image, 'Photos & videos', () => { $('#file').accept = 'image/*,video/*'; $('#file').click(); }],
    [I.folder, 'Files', () => { $('#file').accept = ''; $('#file').click(); }],
    [I.loc, 'Location (paste coordinates)', () => shareLocation()],
  ]);
}
function shareLocation() {
  const v = prompt('Coordinates to send (lat, lon) — the laptop has no GPS:', '');
  if (!v) return;
  const m = /(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/.exec(v);
  if (!m) return toast('Use the form 13.4833, -88.1833');
  const geo = `geo:${(+m[1]).toFixed(6)},${(+m[2]).toFixed(6)}`;
  Chat.echo({ msgtype: 'm.location', body: 'Location: ' + geo.slice(4), geo_uri: geo, 'org.matrix.msc3488.location': { uri: geo } });
}

// ---------------- info drawer ----------------
const Info = {
  toggle() { const i = $('#info'); const on = i.style.display !== 'block'; i.style.display = on ? 'block' : 'none'; if (on) this.render(); },
  render() {
    const r = Chat.room, i = $('#info'); if (!r || i.style.display !== 'block') return;
    i.innerHTML = '';
    const top = h('div', '', ''); top.style.textAlign = 'right';
    const x = h('button', 'ib', I.x); x.onclick = () => this.toggle(); top.appendChild(x); i.appendChild(top);
    const big = avatarEl(R.name(r), r.avatar, 96, r.dm); big.classList.add('big'); i.appendChild(big);
    i.appendChild(h('h2', '', esc(R.name(r))));
    i.appendChild(h('div', 'sub', esc(r.dm ? 'WhatsApp' : 'WhatsApp group · ' + Math.max(0, r.joined - 1) + ' people')));
    const btns = h('div', 'ibtns');
    const mk = (icon, label, fn) => { const b = h('button', 'ibtn', icon + '<span>' + esc(label) + '</span>'); b.onclick = fn; btns.appendChild(b); };
    mk(I.search, 'Search', () => Chat.toggleSearch(true));
    mk(I.pin, r.pinned ? 'Unpin' : 'Pin', () => { pinRoom(r, !r.pinned); renderList(); this.render(); });
    mk(I.unread, 'Unread', () => { markUnread(r, true); renderList(); });
    mk(I.hide, R.hidden(r) ? 'Unhide' : 'Hide', () => { hideRoom(r, !R.hidden(r)); renderList(); this.render(); });
    i.appendChild(btns);
    const photos = Chat.msgs.filter(m => m.msgtype === 'm.image' && m.mxc && !m.redacted).reverse().slice(0, 30);
    if (photos.length) {
      i.appendChild(h('div', 'sec', 'Media · ' + photos.length + ' loaded'));
      const g = h('div', 'grid');
      for (const m of photos) {
        const d = h('div', '');
        if (revealed.has(m.mxc) || prefs.get('autophotos', false)) d.style.backgroundImage = `url("${media(m.mxc, 320)}")`; else d.textContent = 'click';
        d.onclick = () => { revealed.add(m.mxc); Viewer.show(m); this.render(); };
        g.appendChild(d);
      }
      i.appendChild(g);
    }
    if (!r.dm) {
      const ppl = [...new Set(Object.entries(r.names).filter(([u]) => u !== S.me && !R.isBot(u)).map(([, n]) => n))].sort((a, b) => a.localeCompare(b));
      i.appendChild(h('div', 'sec', 'People seen so far · ' + ppl.length));
      for (const n of ppl) { const p = h('div', 'person'); p.appendChild(avatarEl(n, null, 36, true)); p.appendChild(h('span', '', esc(n))); i.appendChild(p); }
    }
  }
};

// ---------------- viewer ----------------
const Viewer = {
  m: null, z: 1, x: 0, y: 0,
  show(m) {
    this.m = m; this.z = 1; this.x = 0; this.y = 0;
    $('#vimg').src = media(m.mxc); this.apply();
    $('#vcap').textContent = (m.mine ? 'You' : R.nameOf(Chat.room, m.sender)) + ' · ' + listTime(m.ts);
    $('#viewer').style.display = 'flex';
  },
  hide() { $('#viewer').style.display = 'none'; $('#vimg').src = ''; },
  apply() { $('#vimg').style.transform = `translate(${this.x}px,${this.y}px) scale(${this.z})`; $('#vimg').style.cursor = this.z > 1 ? 'grab' : 'zoom-in'; }
};


// ---------------- updates (GitHub: sigmajulio/chat-updates) ----------------
const Upd = {
  info: null, busy: false, lastCheck: +(LS.getItem('upd_last') || 0),
  async check(manual) {
    if (!HOST.updCheck) { if (manual) toast('Updates only work in the desktop app'); return null; }
    const r = await HOST.updCheck();
    this.lastCheck = Date.now(); LS.setItem('upd_last', this.lastCheck);
    this.info = r; this.banner();
    if (manual) toast(r.error ? 'Couldn’t check: ' + r.error : r.latest > r.current ? `Version ${r.latest} is available` : `You’re on the latest version (v${r.current})`);
    return r;
  },
  available() { return this.info && !this.info.error && this.info.latest > this.info.current; },
  banner() {
    let b = $('#upd');
    if (!this.available()) { if (b) b.remove(); return; }
    if (!b) { b = h('div', ''); b.id = 'upd'; $('#status').after(b); }
    b.innerHTML = `<span>Update v${this.info.latest} available</span>`;
    const go = h('button', '', this.busy ? '…' : 'Install'); go.onclick = () => this.install(); b.appendChild(go);
  },
  async install(statusEl) {
    if (this.busy || !HOST.updInstall) return;
    this.busy = true; this.banner();
    const show = t => { const b = $('#upd span'); if (b) b.textContent = t; if (statusEl) statusEl.textContent = t; };
    HOST.onUpd && HOST.onUpd(p => show(`${p.msg}${p.pct < 100 ? ' · ' + p.pct + '%' : ''}`));
    try { saveCache(true); await HOST.updInstall(); show('Restarting…'); }
    catch (e) { this.busy = false; this.banner(); show('Update failed: ' + (e.message || e)); toast('Update failed: ' + (e.message || e)); }
  },
  auto() {
    const run = () => { if (prefs.get('autoupdate', true) && Date.now() - this.lastCheck > 6 * 3600e3) this.check(false).catch(() => {}); };
    setTimeout(() => { if (prefs.get('autoupdate', true)) this.check(false).catch(() => {}); }, 8000);
    setInterval(run, 30 * 60e3);
  }
};

// ---------------- modals: settings, new chat ----------------
function modal(title, body) {
  closeModal();
  const s = h('div', 'scrim'); s.id = 'modal';
  const c = h('div', 'card modal');
  const hd = h('header', '', '<span>' + esc(title) + '</span>');
  const x = h('button', 'ib', I.x); x.onclick = closeModal; hd.appendChild(x);
  const b = h('div', 'body'); b.appendChild(body);
  c.append(hd, b); s.appendChild(c);
  s.onclick = e => { if (e.target === s) closeModal(); };
  document.body.appendChild(s);
  return c;
}
function closeModal() { const m = $('#modal'); if (m) m.remove(); }
function settings() {
  const b = h('div', '');
  const sec = t => b.appendChild(h('div', 'sec', esc(t)));
  const toggle = (label, key, def, theme) => {
    const row = h('div', 'set', `<span class="lbl">${esc(label)}</span>`);
    const sw = h('div', 'sw' + (prefs.get(key, def) ? ' on' : ''));
    row.appendChild(sw);
    row.onclick = () => { prefs.set(key, !prefs.get(key, def)); sw.classList.toggle('on'); if (theme) { applyTheme(); renderList(); if (Chat.room) Chat.render(); } };
    b.appendChild(row);
  };
  const choice = (label, key, def, opts, theme) => {
    const row = h('div', 'set', `<span class="lbl">${esc(label)}</span>`);
    const sel = h('select', '');
    for (const [v, l] of opts) { const o = h('option', '', esc(l)); o.value = v; if (prefs.get(key, def) === v) o.selected = true; sel.appendChild(o); }
    sel.onchange = () => { prefs.set(key, sel.value); if (theme) applyTheme(); renderList(); if (Chat.room) { Chat.render(); Chat.header(); } };
    row.appendChild(sel); b.appendChild(row);
  };
  sec('Appearance');
  choice('Accent color', 'accent', 'gray', [['gray', 'Gray (grayscale)'], ['blue', 'Blue (Beeper)']], true);
  toggle('Pure black background', 'amoled', true, true);
  choice('Text size', 'textsize', 'normal', [['small', 'Small'], ['normal', 'Normal'], ['large', 'Large']], true);
  sec('Chats');
  choice('Quick reaction (double-click)', 'quick', '❤️', ['❤️', '👍', '😂', '🔥', '🙏', '😮'].map(e => [e, e]));
  toggle('Transcribe voice notes', 'transcribe', true);
  toggle('Load photos automatically', 'autophotos', false);
  toggle('Send typing indicator', 'sendtyping', true);
  toggle('Send read receipts', 'sendread', true);
  sec('Updates');
  toggle('Check for updates automatically', 'autoupdate', true);
  const ur = h('div', 'set', `<span class="lbl">Check for updates<div class="val" id="updv">Installed: v${Upd.info ? Upd.info.current : '…'}${Upd.available() ? ' · v' + Upd.info.latest + ' available' : ''}</div></span>`);
  const ub = h('button', 'pillbtn', Upd.available() ? 'Install v' + Upd.info.latest : 'Check');
  const refresh = () => { const v = $('#updv'); const i = Upd.info || {}; if (v) v.textContent = i.error ? 'Couldn’t check: ' + i.error : `Installed: v${i.current} · latest: v${i.latest}` + (Upd.available() ? ' (update available)' : ' (up to date)'); ub.textContent = Upd.available() ? 'Install v' + i.latest : 'Check'; };
  ub.onclick = async e => { e.stopPropagation(); if (Upd.available()) return Upd.install($('#updv')); ub.textContent = 'Checking…'; await Upd.check(false).catch(() => {}); refresh(); };
  ur.appendChild(ub); b.appendChild(ur);
  if (Upd.info && Upd.info.notes) b.appendChild(h('div', 'set', `<span class="lbl val" style="color:var(--dim);font-size:13px">What’s new: ${esc(Upd.info.notes)}</span>`));
  if (!Upd.info && HOST.updCheck) Upd.check(false).then(refresh).catch(() => {});
  sec('Account');
  b.appendChild(h('div', 'set', `<span class="lbl">${esc(S.me || '')}<div class="val">${esc(S.hs)}</div></span>`));
  const lo = h('div', 'set', '<span class="lbl" style="color:var(--red)">Log out</span>');
  lo.onclick = () => { if (confirm('Log out of chat on this laptop?')) { bg(() => api('POST', '/_matrix/client/v3/logout', {})); closeModal(); logout(); } };
  b.appendChild(lo);
  sec('Keyboard');
  b.appendChild(h('div', 'set', '<span class="lbl val" style="color:var(--dim);font-size:13px;line-height:1.7">Ctrl+K search chats · Ctrl+N new chat · Alt+↑/↓ previous/next chat · Ctrl+F search in chat · Ctrl+I chat info · Esc close / cancel reply · Enter send · Shift+Enter new line · ↑ in empty box edits your last message · Ctrl+R reload</span>'));
  modal('Settings', b);
}
let contacts = null;
async function newChat() {
  const b = h('div', '');
  const sbox = h('div', 'search', I.search + '<input placeholder="Name or number" spellcheck="false">');
  sbox.style.margin = '4px 8px 10px';
  const list = h('div', '');
  b.append(sbox, list);
  modal('New chat', b);
  const inp = sbox.querySelector('input'); inp.focus();
  if (!contacts) {
    list.innerHTML = '<div style="color:var(--dim);padding:12px">Loading contacts…</div>';
    const r = await prov('GET', '/contacts');
    contacts = (r.json.contacts || []).map(parseContact).sort((a, b) => a.name.localeCompare(b.name));
  }
  let remote = [], timer2 = 0;
  const draw = () => {
    const q = fold(inp.value.trim()), digits = inp.value.replace(/[\s\-()]/g, '');
    list.innerHTML = '';
    if (/^\+?\d{7,15}$/.test(digits)) {
      const num = digits.startsWith('+') ? digits : '+' + (digits.length === 8 ? '503' + digits : digits);
      list.appendChild(ncRow({ id: num, name: 'Message ' + num, phone: null }));
    }
    const seen = new Set();
    for (const c of contacts) if (!q || fold(c.name).includes(q) || (c.phone || '').includes(q)) { list.appendChild(ncRow(c)); seen.add(c.id); }
    for (const c of remote) if (!seen.has(c.id)) list.appendChild(ncRow(c));
  };
  const ncRow = c => {
    const row = h('div', 'nc'); row.appendChild(avatarEl(c.name, null, 38, true));
    row.appendChild(h('div', '', `<div>${esc(c.name)}</div>${c.phone ? `<div class="ph">${esc(c.phone)}</div>` : ''}`));
    row.onclick = () => startDm(c);
    return row;
  };
  inp.oninput = () => {
    draw(); clearTimeout(timer2); remote = [];
    const q = inp.value.trim();
    if (q.length >= 2 && !/^\+?[\d\s\-()]+$/.test(q)) timer2 = setTimeout(async () => {
      const r = await prov('POST', '/search_users', { query: q });
      if (inp.value.trim() === q) { remote = (r.json.results || []).map(parseContact); draw(); }
    }, 400);
  };
  inp.onkeydown = e => { if (e.key === 'Enter') { const f = list.querySelector('.nc'); if (f) f.click(); } };
  draw();
}
function parseContact(o) {
  const tel = (o.identifiers || []).find(x => x.startsWith('tel:'));
  return { id: o.id, name: o.name || (tel ? tel.slice(4) : o.id), phone: tel ? tel.slice(4) : null, dm: o.dm_room_mxid || null };
}
async function startDm(c) {
  if (c.dm) { closeModal(); return openRoom(c.dm); }
  if (TEST) return toast('test mode: not creating chats');
  toast('Opening chat…');
  const r = await prov('POST', '/create_dm/' + enc(c.id), {});
  if (r.code !== 200 || !r.json.dm_room_mxid) return toast(r.json.error || 'Couldn’t start that chat');
  contacts = null; closeModal();
  const room = R.get(r.json.dm_room_mxid);
  if (!room.name && !room.heroes.length) { room.name = c.name.startsWith('Message ') ? c.id : c.name; room.dm = true; }
  openRoom(room.id);
}
async function searchAll(term) {
  const r = await api('POST', '/_matrix/client/v3/search', { search_categories: { room_events: { search_term: term, order_by: 'recent' } } });
  const res = (((r.json.search_categories || {}).room_events || {}).results || []).map(x => x.result).filter(e => e && S.rooms.has(e.room_id) && !R.system(S.rooms.get(e.room_id)));
  const b = h('div', '');
  if (!res.length) b.appendChild(h('div', '', '<div style="color:var(--dim);padding:12px">No messages found</div>'));
  for (const ev of res.slice(0, 50)) {
    const room = S.rooms.get(ev.room_id);
    const row = h('div', 'nc'); row.appendChild(avatarEl(R.name(room), room.avatar, 36, room.dm));
    row.appendChild(h('div', '', `<div>${esc(R.name(room))} <span class="ph">· ${listTime(ev.origin_server_ts)}</span></div><div class="ph">${esc((ev.sender === S.me ? 'You' : R.nameOf(room, ev.sender)) + ': ' + ((ev.content || {}).body || '').slice(0, 120))}</div>`));
    row.onclick = () => { closeModal(); openRoom(ev.room_id, ev.event_id); };
    b.appendChild(row);
  }
  modal('Messages matching “' + term + '”', b);
}

// ---------------- wiring ----------------
function showLogin() {
  $('#login').style.display = 'flex'; $('#lhs').value = S.hs || DEFAULT_HS; $('#lpass').focus();
}
function wire() {
  $('#q').oninput = e => { S.query = e.target.value.trim(); renderList(); };
  $('#q').onkeydown = e => {
    if (e.key === 'Enter' && S.query) { if (shownRooms.length && !e.shiftKey && fold(R.name(shownRooms[0])).includes(fold(S.query))) { openRoom(shownRooms[0].id); } else searchAll(S.query); }
    if (e.key === 'Escape') { e.target.value = ''; S.query = ''; renderList(); $('#inp').focus(); }
  };
  $('#gear').onclick = settings;
  $('#fab').onclick = newChat;
  $('#inp').oninput = () => { autosize(); updateSend(); typing($('#inp').value.length > 0); };
  $('#inp').onkeydown = e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); Chat.send(); }
    else if (e.key === 'ArrowUp' && !$('#inp').value) { const m = [...Chat.msgs].reverse().find(x => x.mine && x.msgtype === 'm.text' && !x.redacted && x.id && !x.id.startsWith('~')); if (m) { e.preventDefault(); Chat.startEdit(m); } }
  };
  $('#inp').onpaste = e => { const files = [...(e.clipboardData.files || [])]; if (files.length) { e.preventDefault(); files.forEach(f => Chat.upload(f)); } };
  $('#send').onclick = () => { if ($('#inp').value.trim() || Chat.editing) Chat.send(); else Rec.start(); };
  $('#plus').onclick = () => { if (Rec.mr || Rec.blob) Rec.cancel(); else attachMenu(); };
  $('#rpause').onclick = () => Rec.pause();
  $('#ract').onclick = () => Rec.blob ? Rec.send() : Rec.finish();
  $('#file').onchange = e => { [...e.target.files].forEach(f => Chat.upload(f)); e.target.value = ''; };
  $('#ctxX').onclick = () => { if (Chat.editing) { Chat.editing = null; $('#inp').value = ''; autosize(); updateSend(); } Chat.replyTo = null; Chat.ctx(); };
  $('#cq').onkeydown = e => { if (e.key === 'Enter') Chat.search(e.target.value.trim()); if (e.key === 'Escape') Chat.toggleSearch(false); };
  $('#down').onclick = () => Chat.toBottom();
  $('#msgs').onscroll = () => {
    const b = $('#msgs');
    if (b.scrollTop < 200 && !Chat.loading && !Chat.noMore) Chat.loadOlder();
    if (Chat.ctxMode && b.scrollHeight - b.scrollTop - b.clientHeight < 200) Chat.loadNewer();
    updateDown();
  };
  $('#msgs').onclick = e => { const a = e.target.closest('a[data-ext]'); if (a) { e.preventDefault(); HOST.open(a.href); } };
  // drag & drop
  const conv = $('#conv'); let depth = 0;
  conv.ondragenter = e => { if (e.dataTransfer.types.includes('Files')) { depth++; $('#drop').style.display = 'flex'; } };
  conv.ondragleave = () => { if (--depth <= 0) { depth = 0; $('#drop').style.display = 'none'; } };
  conv.ondragover = e => e.preventDefault();
  conv.ondrop = e => { e.preventDefault(); depth = 0; $('#drop').style.display = 'none'; [...e.dataTransfer.files].forEach(f => Chat.upload(f)); };
  // viewer
  $('#vclose').onclick = () => Viewer.hide();
  $('#vsave').onclick = () => Viewer.m && save(Viewer.m);
  $('#viewer').onclick = e => { if (e.target.id === 'viewer') Viewer.hide(); };
  $('#vimg').onwheel = e => { e.preventDefault(); Viewer.z = Math.max(1, Math.min(6, Viewer.z * (e.deltaY < 0 ? 1.15 : 0.87))); if (Viewer.z === 1) { Viewer.x = Viewer.y = 0; } Viewer.apply(); };
  $('#vimg').ondblclick = () => { Viewer.z = Viewer.z > 1 ? 1 : 2.5; Viewer.x = Viewer.y = 0; Viewer.apply(); };
  let drag = null;
  $('#vimg').onmousedown = e => { if (Viewer.z > 1) { e.preventDefault(); drag = { x: e.clientX - Viewer.x, y: e.clientY - Viewer.y }; } };
  addEventListener('mousemove', e => { if (drag) { Viewer.x = e.clientX - drag.x; Viewer.y = e.clientY - drag.y; Viewer.apply(); } });
  addEventListener('mouseup', () => drag = null);
  // keyboard
  addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if ($('#viewer').style.display === 'flex') return Viewer.hide();
      if ($('#popup')) return closePopups();
      if ($('#modal')) return closeModal();
      if (Rec.mr || Rec.blob) return Rec.cancel();
      if (Chat.replyTo || Chat.editing) return $('#ctxX').click();
      if ($('#chatSearch').style.display === 'block') return Chat.toggleSearch(false);
    }
    if (e.ctrlKey && e.key.toLowerCase() === 'k') { e.preventDefault(); $('#q').focus(); $('#q').select(); }
    if (e.ctrlKey && e.key.toLowerCase() === 'n') { e.preventDefault(); newChat(); }
    if (e.ctrlKey && e.key.toLowerCase() === 'f' && Chat.room) { e.preventDefault(); Chat.toggleSearch(true); }
    if (e.ctrlKey && e.key.toLowerCase() === 'i' && !e.shiftKey && Chat.room) { e.preventDefault(); Info.toggle(); }
    if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) { e.preventDefault(); moveRoom(e.key === 'ArrowUp' ? -1 : 1); }
  });
  addEventListener('focus', () => { if (Chat.room) Chat.markLatest(); });
  addEventListener('beforeunload', () => { if (Chat.room) { const v = $('#inp').value; v ? LS.setItem('draft_' + Chat.room.id, v) : LS.removeItem('draft_' + Chat.room.id); } saveCache(true); });
  $('#lgo').onclick = async () => {
    $('#lerr').textContent = ''; $('#lgo').disabled = true;
    const err = await login($('#lhs').value.trim(), $('#luser').value.trim(), $('#lpass').value).catch(e => e.message);
    $('#lgo').disabled = false;
    if (err) { $('#lerr').textContent = err; return; }
    $('#login').style.display = 'none'; start();
  };
  $('#lpass').onkeydown = e => { if (e.key === 'Enter') $('#lgo').click(); };
}
function start() {
  HOST.auth(S.hs, S.token);
  loadCache(); renderList(); syncLoop();
  setInterval(() => { if (Chat.room) Chat.header(); }, 30000);
  Upd.auto();
}

applyTheme();
wire();
updateSend();
if (S.token) start(); else showLogin();
