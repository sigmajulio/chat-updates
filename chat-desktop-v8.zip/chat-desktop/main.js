// chat desktop — Electron main process (runs on the wa-engine Electron)
const { app, BrowserWindow, ipcMain, shell, session, Menu } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), cp = require('child_process');

app.setName('chat');
if (!app.requestSingleInstanceLock()) { app.quit(); }
let win = null, auth = { hs: '', token: '' };

function create() {
  const ses = session.fromPartition('persist:chat');
  // authenticated media: add the Matrix token to requests for our homeserver's media
  ses.webRequest.onBeforeSendHeaders({ urls: ['https://*/*'] }, (d, cb) => {
    if (auth.token && auth.hs && d.url.startsWith(auth.hs + '/_matrix/client/v1/media/')) d.requestHeaders['Authorization'] = 'Bearer ' + auth.token;
    cb({ requestHeaders: d.requestHeaders });
  });
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(perm === 'media' || perm === 'clipboard-read' || perm === 'clipboard-sanitized-write'));
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1180, height: 780, minWidth: 720, minHeight: 480, backgroundColor: '#000000', title: 'chat', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), session: ses, contextIsolation: true, nodeIntegration: false, spellcheck: false, webSecurity: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  // automated checks only: CHAT_TEST_SCRIPT=<file> injects a script after load (unused in normal runs)
  if (process.env.CHAT_TEST_SCRIPT) win.webContents.on('did-finish-load', () => win.webContents.executeJavaScript(fs.readFileSync(process.env.CHAT_TEST_SCRIPT, 'utf8')).catch(e => console.log('TESTERR', e)));
  if (process.env.CHAT_TEST_SCRIPT) win.webContents.on('console-message', (e, lvl, msg) => console.log('[page]', msg));
  // links never open inside the app: hand them to the system (wa)
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) { e.preventDefault(); shell.openExternal(url); } });
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && i.control && i.shift && i.key.toLowerCase() === 'i') win.webContents.toggleDevTools();
    if (i.type === 'keyDown' && i.control && !i.shift && i.key.toLowerCase() === 'r') win.reload();
  });
}

ipcMain.handle('auth', (e, a) => { auth = a || { hs: '', token: '' }; return true; });
ipcMain.handle('open', (e, url) => { if (/^(https?|geo|mailto):/i.test(url)) shell.openExternal(url); return true; });
ipcMain.handle('title', (e, t) => { if (win) win.setTitle(t); return true; });
// Chromium records WebM; WhatsApp needs Ogg/Opus → remux with ffmpeg (no re-encode)
ipcMain.handle('remux', async (e, bytes) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-voice-'));
  const inp = path.join(dir, 'in.webm'), out = path.join(dir, 'out.ogg');
  fs.writeFileSync(inp, Buffer.from(bytes));
  try {
    await new Promise((ok, bad) => cp.execFile('ffmpeg', ['-y', '-loglevel', 'error', '-i', inp, '-vn', '-c:a', 'copy', out],
      { timeout: 30000 }, (err, so, se) => err ? bad(new Error(se || err.message)) : ok()));
    return fs.readFileSync(out);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});


// ---------------- self-update from GitHub (sigmajulio/chat-updates) ----------------
// latest.json: { version, notes, date, android:{file,sha256,size}, desktop:{file,sha256,size} }
const crypto = require('crypto');
const REPO = 'sigmajulio/chat-updates';
const VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).chatVersion || 0; } catch { return 0; } })();
// automated checks only: CHAT_UPD_BASE=<url/> serves latest.json + zips locally (unused in normal runs)
const TESTBASE = process.env.CHAT_UPD_BASE || '';
const RAWBASE = TESTBASE || `https://raw.githubusercontent.com/${REPO}/main/`;
async function manifest() {
  if (TESTBASE) { const r = await fetch(TESTBASE + 'latest.json'); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }
  const tries = [
    [`https://api.github.com/repos/${REPO}/contents/latest.json?ref=main`, { Accept: 'application/vnd.github.raw', 'User-Agent': 'chat-desktop' }],
    [`https://raw.githubusercontent.com/${REPO}/main/latest.json?t=${Date.now()}`, {}],
  ];
  let last = null;
  for (const [u, h] of tries) {
    try { const r = await fetch(u, { headers: h, cache: 'no-store' }); if (r.ok) return await r.json(); last = new Error('HTTP ' + r.status); }
    catch (e) { last = e; }
  }
  throw last || new Error('no manifest');
}
ipcMain.handle('upd-check', async () => {
  try { const m = await manifest(); const dv = (m.desktop && m.desktop.version) || m.version || 0; return { current: VERSION, latest: m.desktop && m.desktop.file ? dv : 0, notes: m.notes || '', file: m.desktop && m.desktop.file, size: m.desktop && m.desktop.size }; }
  catch (e) { return { current: VERSION, error: String(e.message || e) }; }
});
ipcMain.handle('upd-install', async (e) => {
  const send = (pct, msg) => { try { e.sender.send('upd-progress', { pct, msg }); } catch {} };
  const m = await manifest();
  const d = m.desktop;
  if (!d || !d.file || !((d.version || m.version) > VERSION)) throw new Error('No newer desktop version');
  send(0, 'Downloading ' + d.file);
  const r = await fetch(RAWBASE + d.file, { cache: 'no-store' });
  if (!r.ok) throw new Error('Download failed: HTTP ' + r.status);
  const total = +r.headers.get('content-length') || d.size || 0, parts = []; let got = 0;
  const rd = r.body.getReader();
  for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(value); got += value.length; if (total) send(Math.min(99, Math.round(got * 100 / total)), `Downloading ${Math.round(got / 1024)} / ${Math.round(total / 1024)} KB`); }
  const buf = Buffer.concat(parts);
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  if (d.sha256 && sha !== d.sha256) throw new Error('Checksum mismatch, update not applied');
  send(99, 'Installing');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-upd-'));
  try {
    const zip = path.join(tmp, 'u.zip'); fs.writeFileSync(zip, buf);
    await new Promise((ok, bad) => cp.execFile('python3', ['-I', '-m', 'zipfile', '-e', zip, path.join(tmp, 'x')], { timeout: 30000 }, (err, so, se) => err ? bad(new Error(se || err.message)) : ok()));
    const src = path.join(tmp, 'x', 'chat-desktop');
    for (const f of ['main.js', 'preload.js', 'app.js', 'index.html', 'package.json']) if (!fs.existsSync(path.join(src, f))) throw new Error('Update is missing ' + f);
    // keep the running version so a bad update can be undone by hand
    const prev = path.join(os.homedir(), '.cache', 'chat-desktop-prev');
    fs.rmSync(prev, { recursive: true, force: true }); fs.mkdirSync(prev, { recursive: true });
    for (const f of fs.readdirSync(__dirname)) { const p = path.join(__dirname, f); if (fs.statSync(p).isFile()) fs.copyFileSync(p, path.join(prev, f)); }
    for (const f of fs.readdirSync(src)) { const p = path.join(src, f); if (fs.statSync(p).isFile()) fs.copyFileSync(p, path.join(__dirname, f)); }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  send(100, 'Restarting');
  setTimeout(() => { app.relaunch(); app.exit(0); }, 600);
  return true;
});

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
