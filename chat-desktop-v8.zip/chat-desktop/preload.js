const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('host', {
  auth: (hs, token) => ipcRenderer.invoke('auth', { hs, token }),
  open: (url) => ipcRenderer.invoke('open', url),
  title: (t) => ipcRenderer.invoke('title', t),
  remux: (bytes) => ipcRenderer.invoke('remux', bytes),
  updCheck: () => ipcRenderer.invoke('upd-check'),
  updInstall: () => ipcRenderer.invoke('upd-install'),
  onUpd: (cb) => ipcRenderer.on('upd-progress', (e, p) => cb(p)),
});
